import styles from './privacyPolicy.module.css'
const PrivacyPolicy = () => {
  return (
    <section className={styles.section}>
      <h2 className={styles.heading}>GDPR</h2>
      <p className={styles.text}>
        Lorem ipsum dolor sit amet consectetur adipisicing elit. Sequi assumenda itaque porro repellat facere ad, optio
        rerum. Enim consectetur fugiat, beatae esse veniam saepe cum ducimus aliquid, non magni sunt. Lorem ipsum dolor sit amet consectetur adipisicing elit. Sequi assumenda itaque porro repellat facere ad, optio
        rerum. Enim consectetur fugiat, beatae esse veniam saepe cum ducimus aliquid, non magni sunt.
      </p>
      <p className={styles.text}>
        Lorem ipsum dolor sit amet consectetur adipisicing elit. Sequi assumenda itaque porro repellat facere ad, optio
        rerum. Enim consectetur fugiat, beatae esse veniam saepe cum ducimus aliquid, non magni sunt. Lorem ipsum dolor sit amet consectetur adipisicing elit. Sequi assumenda itaque porro repellat facere ad, optio
        rerum. Enim consectetur fugiat, beatae esse veniam saepe cum ducimus aliquid, non magni sunt.
      </p>
      <p className={styles.text}>
        Lorem ipsum dolor sit amet consectetur adipisicing elit. Sequi assumenda itaque porro repellat facere ad, optio
        rerum. Enim consectetur fugiat, beatae esse veniam saepe cum ducimus aliquid, non magni sunt. Lorem ipsum dolor sit amet consectetur adipisicing elit. Sequi assumenda itaque porro repellat facere ad, optio
        rerum. Enim consectetur fugiat, beatae esse veniam saepe cum ducimus aliquid, non magni sunt.
      </p>
      <p className={styles.text}>
        Lorem ipsum dolor sit amet consectetur adipisicing elit. Sequi assumenda itaque porro repellat facere ad, optio
        rerum. Enim consectetur fugiat, beatae esse veniam saepe cum ducimus aliquid, non magni sunt. Lorem ipsum dolor sit amet consectetur adipisicing elit. Sequi assumenda itaque porro repellat facere ad, optio
        rerum. Enim consectetur fugiat, beatae esse veniam saepe cum ducimus aliquid, non magni sunt.
      </p>
      <p className={styles.text}>
        Lorem ipsum dolor sit amet consectetur adipisicing elit. Sequi assumenda itaque porro repellat facere ad, optio
        rerum. Enim consectetur fugiat, beatae esse veniam saepe cum ducimus aliquid, non magni sunt. Lorem ipsum dolor sit amet consectetur adipisicing elit. Sequi assumenda itaque porro repellat facere ad, optio
        rerum. Enim consectetur fugiat, beatae esse veniam saepe cum ducimus aliquid, non magni sunt.
      </p>
      <p className={styles.text}>
        Lorem ipsum dolor sit amet consectetur adipisicing elit. Sequi assumenda itaque porro repellat facere ad, optio
        rerum. Enim consectetur fugiat, beatae esse veniam saepe cum ducimus aliquid, non magni sunt. Lorem ipsum dolor sit amet consectetur adipisicing elit. Sequi assumenda itaque porro repellat facere ad, optio
        rerum. Enim consectetur fugiat, beatae esse veniam saepe cum ducimus aliquid, non magni sunt.
      </p>
      <p className={styles.text}>
        Lorem ipsum dolor sit amet consectetur adipisicing elit. Sequi assumenda itaque porro repellat facere ad, optio
        rerum. Enim consectetur fugiat, beatae esse veniam saepe cum ducimus aliquid, non magni sunt. Lorem ipsum dolor sit amet consectetur adipisicing elit. Sequi assumenda itaque porro repellat facere ad, optio
        rerum. Enim consectetur fugiat, beatae esse veniam saepe cum ducimus aliquid, non magni sunt.
      </p>
    </section>
  );
};

export default PrivacyPolicy;
